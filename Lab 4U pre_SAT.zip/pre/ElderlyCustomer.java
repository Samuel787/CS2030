public class ElderlyCustomer extends Customer {
  public ElderlyCustomer(int id, double arriveTime) {
    super(id, arriveTime);
  }
}