public interface IUnique<T> {
  public boolean diff(T other);
}